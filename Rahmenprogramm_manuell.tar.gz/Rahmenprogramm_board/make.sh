gcc -g -O0 -mcpu=cortex-a8 -mfpu=neon -mfloat-abi=hard -marm -o default default.c nop.S
